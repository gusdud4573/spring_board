package com.example.spring_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
